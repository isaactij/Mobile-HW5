//
//  CandidateManagerViewController.swift
//  TijerinaIsaac-hw5
//
//  Created by Isaac on 2/24/18.
//  Copyright © 2018 TijerinaIsaac. All rights reserved.
//

import UIKit

class CandidateManagerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
